var express = require('express');
var bodyParser = require('body-parser');
var cons = require('consolidate');
var cookie = require('cookie');
var randomstring = require("randomstring");

var datenow = new Date();
console.log(datenow);

var urlencodedParser = bodyParser.urlencoded({ extended: true });
var app = express();
app.use(bodyParser.json());

const { Gateway,Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');

app.engine('html', cons.swig)
app.set('views', path.join(__dirname, 'views/templates'));
app.set('view engine', 'html');

var userName;
// res.render("allcars",{ list:JSON.parse(result)});


// ###################################get from database##############################################
// ---------------------------------------login---------------------------------------------
app.get('/api/loginfront', function (req, res) {

    res.render('login');

});

app.get('/api/request', function (req, res) {

    res.render('request');

});
// ---------------------------------------login---------------------------------------------
// ------------------------------------registration---------------------------------------------
app.get('/api/registration', function (req, res) {

    res.render('registration');

});

//----------------------------------add to store view-----------------------------
app.get('/api/addToStoreView', function (req, res) {

    res.render('addproduct');

});


// --------------------------get login data----------------------------------------
app.post('/api/login/', urlencodedParser , async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }
  
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });



        const network = await gateway.getNetwork('mychannel');


        const contract = network.getContract('fabcar');

        const result = await contract.evaluateTransaction('login', req.body.UserId);
        
        const resi=JSON.parse(result);
        const pass=resi.password;
        const role=resi.role;
        const email=resi.store;
        userName=req.body.UserId;

        if(req.body.password==pass){
            var setCookie = cookie.serialize('role', role);
            
            if  (resi.role == "retailer") {
                const resultname = await contract.evaluateTransaction('queryAllusers');
                const paranPass=JSON.parse(resultname);
                res.render('request',{ list:paranPass});
                
            } else if (resi.role == "manufacturer") {
            
                const resultname = await contract.evaluateTransaction('queryAllusers');
                const paranPass=JSON.parse(resultname)    
                res.render("adminview",{data:{ list:paranPass, username:userName}});
                
            } else if (resi.role == "warehouse") {
                const resultname = await contract.evaluateTransaction('queryAllusers');
                const paranPass=JSON.parse(resultname);
                res.render('warehouse',{ list:paranPass});
            } else if (resi.role == "logistic") {
                const resultname = await contract.evaluateTransaction('queryAllusers');
                const paranPass=JSON.parse(resultname);
                res.render('logistic',{ list:paranPass});
            } else if (resi.role == "supplier") {
                const resultname = await contract.evaluateTransaction('queryAllusers');
                const paranPass=JSON.parse(resultname);
                res.render('supplier',{ list:paranPass});
            }           
        }else{
            res.render('fail');
        }
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});
// ---------------------------get login data----------------------------------
// -----------------------------------rgistration---------------------------------------------
// ---------------------------get retailer logistic data ----------------------------------
app.get('/api/getManufactureList/',urlencodedParser ,async function (req, res) {
        try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

    
       const resi=JSON.parse(result);

    
        res.render("list_of_product",{data:{ list:resi, username:userName}});
        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
    });
// ---------------------------get logistic data-------------------------------------

// ---------------------------get warehouse data ----------------------------------
app.get('/api/getWarehouse/:UserId', async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
      
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
    
            const contract = network.getContract('fabcar');
    
            const result = await contract.evaluateTransaction('login', req.params.UserId);
            
            const resi=JSON.parse(result);
            const pass=resi.password;
            const role=resi.role;
    
    
            res.status(200).json({response: result.toString()});
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
    // ---------------------------get warehouse data-------------------------------------
    


// ---------------------------get Manufacture logistic data ----------------------------------
app.get('/api/getLogisticToManufacure', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            
            console.log(JSON.parse(result));

            res.render("test",{ list:JSON.parse(result)});

            
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
    // ---------------------------get logistic data------------------------------------- 
app.get('/api/track', async function (req, res)  {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

        console.log(JSON.parse(result));

        res.render("track",{data:{ list:resi_count, username:userName}});

        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});
   // ---------------------------get logistic data------------------------------------- 
   
app.get('/api/adminview', async function (req, res)  {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

        const res_adminview=JSON.parse(result);
        res.render("adminview",{data:{ list:res_adminview, username:userName}});

        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});
   // ---------------------------get logistic data------------------------------------- 
app.get('/api/aprove', async function (req, res)  {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);


        res_approve=JSON.parse(result);

        res.render("aprove",{data:{ list:res_approve, username:userName}});

        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
});
// ---------------------------get Supplier logistic data ----------------------------------
app.get('/api/getLogisticToSupplier', async function (req, res)  {
        try {
            const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    
    
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
    
            
            const result = await contract.evaluateTransaction('queryAllusers');
    
            const resi_count=JSON.parse(result);
            var count = Object.keys(resi_count).length;
            console.log(count);
    
     
            // const resi=JSON.parse(result)[i];
            // console.log(resi);
    
            for(let i=0;i<count;i++){  
                    const resi=JSON.parse(result)[i]["Record"];
                    console.log(resi);
            }
    
            res.status(200).json({response: result.toString()});
    } catch (error) {
            console.error(`Failed to evaluate transaction: ${error}`);
            res.status(500).json({error: error});
            process.exit(1);
        }
    });
    // ---------------------------get logistic data------------------------------------- 
    
    
// #######################################get from database##################################


app.post('/api/addcar/', urlencodedParser, async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
        
        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');
        console.log('attmpt to fetch'); 
        console.log(req.toString()); 
        if(req.body.password==req.body.repassword){
           
            await contract.submitTransaction('createCar', req.body.id, req.body.role, req.body.store, req.body.password, req.body.logistic, req.body.companyName, req.body.companyAddress, req.body.companyEmail, req.body.phone,req.body.status);
            console.log('Transaction has been submitted');
            res.send('Transaction has been submitted');
        }else{
            console.log('password  didnt matched'); 
        }

        await gateway.disconnect();
} catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }
})

// ###################################################################
app.post('/api/addlog/',urlencodedParser, async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
    
            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    
            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }
    
            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
            
            const network = await gateway.getNetwork('mychannel');
    
            const contract = network.getContract('fabcar');
            console.log('Transaction has try');
            const retailerID=userName;  //session eken ganda
            const userID=userName;   //session eken ganda
            const OrderID=randomstring.generate(10);
            const date=datenow;
            console.log(req.body.quantity);
            console.log(req.body.status);
            console.log(OrderID);
            const resetarry=req.body.product.split(',');
            console.log(resetarry[0]);
            console.log(resetarry[1]);
            await contract.submitTransaction('addLogistic',userID, OrderID,resetarry[0],retailerID, resetarry[1],req.body.quantity,req.body.status,date,req.body.manufacture);
            console.log('Transaction has been submitted');
            res.send('Transaction has been submitted');
    
            await gateway.disconnect();
    } catch (error) {
            console.error(`Failed to submit transaction: ${error}`);
            process.exit(1);
        }
    })
// #################################################################
// ###################################################################
app.post('/api/addToStore/',urlencodedParser, async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
        
        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');
        console.log('Transaction has try');

        const pdetaiNo=randomstring.generate(9);
        console.log(req.body.productID);
        const userid=userName;
        await contract.submitTransaction('addStore',userid, pdetaiNo,req.body.product,req.body.pdetails);
        console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');

        await gateway.disconnect();
} catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    }
})
// #################################################################

app.post('/api/changeowner/:car_index',urlencodedParser ,async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);


        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel'); 


        const contract = network.getContract('fabcar');

        await contract.submitTransaction('changeCarOwner', req.params.car_index, req.body.owner);
        console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');

        await gateway.disconnect();
} catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    } 
})

// #################################################update status#########################
app.post('/api/UpdateStatus/', urlencodedParser ,async function (req, res) {
        try {
    const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
            const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

            const walletPath = path.join(process.cwd(), 'wallet');
            const wallet = await Wallets.newFileSystemWallet(walletPath);
            console.log(`Wallet path: ${walletPath}`);
    

            const identity = await wallet.get('appUser');
            if (!identity) {
                console.log('An identity for the user "appUser" does not exist in the wallet');
                console.log('Run the registerUser.js application before retrying');
                return;
            }

            const gateway = new Gateway();
            await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });
    

            const network = await gateway.getNetwork('mychannel'); 
 
            const contract = network.getContract('fabcar');
  
            await contract.submitTransaction('UpdateStatus', req.body.UserId, req.body.OrderId,req.body.newStatus);
            await contract.submitTransaction('addStatus', req.body.UserId, req.body.OrderId,req.body.newStatus,datenow);
            console.log('Transaction has been submitted');
            res.send('Transaction has been submitted');

            await gateway.disconnect();
    } catch (error) {
            console.error(`Failed to submit transaction: ${error}`);
            process.exit(1);
        } 
    })
// ################################################update ststus#########################

app.post('/api/updateWarehouse/', urlencodedParser ,async function (req, res) {
    try {
const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);


        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }
  
        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel'); 


        const contract = network.getContract('fabcar');
        
        await contract.submitTransaction('addStatus', req.body.UserId, req.body.OrderId,req.body.newStatus,datenow);
        await contract.submitTransaction('UpdateWarehouse', req.body.UserId, req.body.OrderId,req.body.newStatus);
        
        console.log('Transaction has been submitted');
        res.send('Transaction has been submitted');

        await gateway.disconnect();
} catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        process.exit(1);
    } 
})

app.post('/api/tracksingleproduct/', urlencodedParser ,async function (req, res) {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

    
       const resi=JSON.parse(result);
       console.log(JSON.parse(result));
       console.log(req.body.OrderId);
       const orderid=req.body.OrderId;
       
       var logisarray = [];
       
       for(let i=0;i<count;i++){  
                const resi=JSON.parse(result)[i]["Record"];
                logisarray.push(resi);
         }
        console.log("logis array") 
        console.log(logisarray);//json stringfy karanda
    
        res.render("blank",{data:{ list:logisarray, orderid:orderid}});
        //res.render('blank',{ list:logisarray});
        

    // res.status(200).json({response: result.toString()});
        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
})

//##############################track history watrhouse######################################3
app.post('/api/tracksingleproductwarehouse/', urlencodedParser ,async function (req, res) {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

    
       const resi=JSON.parse(result);
       console.log(JSON.parse(result));
       console.log(req.body.OrderId);
       const orderid=req.body.OrderId;
       
       var logisarray = [];
       
       for(let i=0;i<count;i++){  
                const resi=JSON.parse(result)[i]["Record"];
                logisarray.push(resi);
         }
        console.log("logis array") 
        console.log(logisarray);//json stringfy karanda
    
        res.render("blankWarehouse",{data:{ list:logisarray, orderid:orderid}});
        //res.render('blank',{ list:logisarray});
        

    // res.status(200).json({response: result.toString()});
        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
})
//##############################track History logistic#####################################
//##############################track history watrhouse#################################
app.post('/api/tracksingleproductLogostic/', urlencodedParser ,async function (req, res) {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

    
       const resi=JSON.parse(result);
       console.log(JSON.parse(result));
       console.log(req.body.OrderId);
       const orderid=req.body.OrderId;
       
       var logisarray = [];
       
       for(let i=0;i<count;i++){  
                const resi=JSON.parse(result)[i]["Record"];
                logisarray.push(resi);
         }
        console.log("logis array") 
        console.log(logisarray);//json stringfy karanda
    
        res.render("blankLogistic",{data:{ list:logisarray, orderid:orderid}});
        //res.render('blank',{ list:logisarray});
        

    // res.status(200).json({response: result.toString()});
        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
})
//###########################track History logistic#####################################
//##############################track history supplier#################################
app.post('/api/trackSupplier/', urlencodedParser ,async function (req, res) {
    try {
        const ccpPath = path.resolve(__dirname, '..', '..', 'test-network', 'organizations', 'peerOrganizations', 'org1.example.com', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));

        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);

        const identity = await wallet.get('appUser');
        if (!identity) {
            console.log('An identity for the user "appUser" does not exist in the wallet');
            console.log('Run the registerUser.js application before retrying');
            return;
        }

        const gateway = new Gateway();
        await gateway.connect(ccp, { wallet, identity: 'appUser', discovery: { enabled: true, asLocalhost: true } });


        const network = await gateway.getNetwork('mychannel');

        const contract = network.getContract('fabcar');

        
        const result = await contract.evaluateTransaction('queryAllusers');

        const resi_count=JSON.parse(result);
        var count = Object.keys(resi_count).length;
        console.log(count);

    
       const resi=JSON.parse(result);
       console.log(JSON.parse(result));
       console.log(req.body.OrderId);
       const orderid=req.body.OrderId;
       
       var logisarray = [];
       
       for(let i=0;i<count;i++){  
                const resi=JSON.parse(result)[i]["Record"];
                logisarray.push(resi);
         }
        console.log("logis array")         
        
        console.log(logisarray);//json stringfy karanda
    
        res.render("blankSupplier",{data:{ list:logisarray, orderid:orderid}});
        //res.render('blank',{ list:logisarray});
        

    // res.status(200).json({response: result.toString()});
        
} catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        res.status(500).json({error: error});
        process.exit(1);
    }
})
//###########################track History supplier#####################################

app.listen(8080);
